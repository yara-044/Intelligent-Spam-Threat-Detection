-- Run this once in Supabase SQL Editor before deploying the updated app.
ALTER TABLE public.email_scan_archive
ADD COLUMN IF NOT EXISTS gmail_account_email text;

-- Replace the old uniqueness rule (user_id, gmail_message_id) with one
-- that also includes the connected Gmail mailbox.
DO $$
DECLARE
    c RECORD;
BEGIN
    FOR c IN
        SELECT con.conname
        FROM pg_constraint con
        JOIN pg_class tbl ON tbl.oid = con.conrelid
        JOIN pg_namespace ns ON ns.oid = tbl.relnamespace
        WHERE ns.nspname = 'public'
          AND tbl.relname = 'email_scan_archive'
          AND con.contype = 'u'
          AND (
              SELECT array_agg(att.attname ORDER BY att.attname)
              FROM unnest(con.conkey) AS key_col(attnum)
              JOIN pg_attribute att
                ON att.attrelid = tbl.oid AND att.attnum = key_col.attnum
          ) = ARRAY['gmail_message_id', 'user_id']::name[]
    LOOP
        EXECUTE format(
            'ALTER TABLE public.email_scan_archive DROP CONSTRAINT %I',
            c.conname
        );
    END LOOP;
END $$;

ALTER TABLE public.email_scan_archive
ADD CONSTRAINT email_scan_archive_user_mailbox_message_key
UNIQUE (user_id, gmail_account_email, gmail_message_id);
